#include <stdio.h>
#include <stdlib.h>
#include "carte.h"
#include "pioche.h"

carte jeudessai[32] = {{7,'R'},{8,'R'},{9,'R'},{10,'R'},{11,'R'},{12,'R'},{13,'R'},{14,'R'},
    {7,'T'},{8,'T'},{9,'T'},{10,'T'},{11,'T'},{12,'T'},{13,'T'},{14,'T'},
    {7,'C'},{8,'C'},{9,'C'},{10,'C'},{11,'C'},{12,'C'},{13,'C'},{14,'C'},
    {7,'P'},{8,'P'},{9,'P'},{10,'P'},{11,'P'},{12,'P'},{13,'P'},{14,'P'}};

int main() {

    exit(EXIT_SUCCESS);
}
