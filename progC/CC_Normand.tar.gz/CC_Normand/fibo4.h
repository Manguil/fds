typedef struct suite {
    int u0;
    int u1;
    int k;
}suite;

void maodifieK(suite *uFib, int nk);

int kNacci(int n);

int fibonacci(int n,suite *uFib);