typedef struct suite {
    int u0;
    int u1;
    int k;
}suite;


int fibonacci(int n,suite *uFib);